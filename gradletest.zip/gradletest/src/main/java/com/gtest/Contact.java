package com.gtest;

import java.util.List;
import java.util.Map;

public class Contact 
{
    public String name;
    public int age;
    public String address;
    public List phoneNumbers;
}

