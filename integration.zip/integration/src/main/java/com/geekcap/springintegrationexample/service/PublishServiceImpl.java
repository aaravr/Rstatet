package com.geekcap.springintegrationexample.service;

import com.geekcap.springintegrationexample.model.Message;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.MessageChannel;
import org.springframework.integration.channel.QueueChannel;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Service;

@Service
public class PublishServiceImpl implements PublishService
{
    private static final Logger logger = Logger.getLogger( PublishServiceImpl.class);

    @Autowired
    private MessageChannel queueChannel;

    @Override
    public void send( Message message )
    {
    	if (message != null) {
    		throw new RuntimeException("testtest");
    	}
        logger.info( "Sending message to message channel: " + message );
        queueChannel.send( MessageBuilder.withPayload( message.toString() ).build() );
    }
}
