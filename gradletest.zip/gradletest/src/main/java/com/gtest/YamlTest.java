package com.gtest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

public class YamlTest {

	public static void main(String[] args) throws FileNotFoundException {
		Yaml yaml = new Yaml();
	
		System.out.println(yaml.dump(yaml.load(new FileInputStream(new File(
				"src/main/resources/config.yml")))));

		Map<String, Map<String, String>> values = (Map<String, Map<String, String>>) yaml
				.load(new FileInputStream(new File("src/main/resources/config.yml")));

		for (String key : values.keySet()) {
			Map<String, String> subValues = values.get(key);
			System.out.println(key);

			for (String subValueKey : subValues.keySet()) {
				System.out.println(String.format("\t%s = %s",
						subValueKey, subValues.get(subValueKey)));
			}
		}
	}
}

