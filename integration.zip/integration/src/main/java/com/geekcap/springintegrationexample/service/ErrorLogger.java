package com.geekcap.springintegrationexample.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.Message;

public class ErrorLogger {
 private static final Logger logger = LoggerFactory.getLogger(ErrorLogger.class);   
   public void logError(Message<Exception> message)
   {
      Exception msgex=message.getPayload();
      logger.error("Exception "+msgex);
      System.out.println("Exception: huraaaaaaaay");
   }
}
