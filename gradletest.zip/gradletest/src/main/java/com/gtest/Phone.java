package com.gtest;

public class Phone
{
    public String name;
    public String number;
}