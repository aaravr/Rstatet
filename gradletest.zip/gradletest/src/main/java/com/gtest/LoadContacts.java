package com.gtest;


import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;

public class LoadContacts {
    private static String yamlLocation="src/main/resources/config.yml";

    public static void main(String[] args) throws IOException{
        Yaml yaml = new Yaml(new Constructor(Collection.class));
        InputStream in = null;
        Collection<Contact> contacts = null;
        try {
            in = new FileInputStream(new File(yamlLocation));
            contacts = (Collection<Contact>) yaml.load(in);
        } catch (IOException e) {
               
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Exception e) {
                    // no-op
                }
            }
        }
        
        
        for(Contact contact:contacts){
            System.out.println(contact.name + ":" + contact.address + ":" + contact.age );
        }
    }
}